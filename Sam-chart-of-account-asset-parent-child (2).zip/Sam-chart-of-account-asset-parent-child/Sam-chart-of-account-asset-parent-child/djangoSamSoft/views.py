from django.shortcuts import redirect


def index2(request):
    return redirect('/Sam/')