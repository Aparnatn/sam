## Getting started
### Follow blow septs
1. pip install -r requirements.txt
2. python manage.py makemigrations
3. python manage.py loaddata category.json
4. Create .env file in root of project Add secret key and db detail in .env file (can copy env.example file)
4. python manage.py runserver